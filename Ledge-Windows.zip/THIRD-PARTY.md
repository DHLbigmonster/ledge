# Dependencies and implementation references

## Shipped dependency

NAudio 2.2.1 by Mark Heath and contributors, MIT license.
https://github.com/naudio/NAudio/tree/v2.2.1

Used for WASAPI system/microphone capture, resampling, mixing and WAV encoding.
The full MIT notice is shipped as `NAUDIO-LICENSE.txt`.
Self-contained packages include Microsoft .NET / Windows Desktop runtime files.
Upstream notices are shipped as `DOTNET-LICENSE.txt`,
`DOTNET-THIRD-PARTY-NOTICES.txt` and `WPF-LICENSE.txt`; retain these files.

## Reference review

- **WinIsland**: https://github.com/WinIslandProject/WinIsland (master; GPL-3.0).
  Reviewed README and `crates/winisland-platform-windows/src/window/styles.rs`
  for platform choices and the use of tool-window / no-activation styles.
  This implementation uses Windows public APIs independently; no source code,
  assets, binaries or plugins from WinIsland are included or linked.
- **DynamicWin**: https://github.com/FlorianButz/DynamicWin (V2; CC BY-SA 4.0).
  Reviewed its feature description. At review time the repository stated that
  it only hosted releases and contained no application source. No assets or
  binaries were used.
- **Ledge Mac**: the sibling `Sources/Ledge` implementation is the product
  reference for shelf behavior, pin protection, notch/handle presentation,
  window parking, screenshot beautification and recording. Windows uses a
  separate native implementation and independent preview version.

Review date: 2026-10-13. These are references, not runtime dependencies.
