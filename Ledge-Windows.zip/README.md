# Ledge for Windows · 纳岛

Windows 原生开发预览 0.1.0（review3）。沿用 Mac 版的本地收纳工作流；不包含转文字功能、Whisper 或语音模型。Windows 源码与 Mac 源码分开维护。本轮改动和验证见 [REVIEW-2026-10-16.md](REVIEW-2026-10-16.md)，前轮调研见 [REVIEW-2026-10-13.md](REVIEW-2026-10-13.md)。

## 运行测试包

支持 Windows 10 22H2 / Windows 11。普通 Intel / AMD 电脑选择 `win-x64`，Windows ARM 设备选择 `win-arm64`。

将 ZIP **完整解压到一个文件夹**，运行 `Ledge.exe`。测试包包含 .NET 桌面运行时，无需另外安装。应用停留在屏幕顶边和系统托盘，不显示任务栏窗口。再次运行会提示已有实例；从托盘可展开、设置或退出。

首次测试请完成 [SMOKE-TEST.md](SMOKE-TEST.md)。本版本没有代码签名和自动更新，尚未做 Windows 实机验收；它不是已验收的正式发行版。

## review3 的体验调整

- 从顶边小把手连续变形成黑色岛，顶部内凹肩角和底部圆角一起过渡，展开有小幅回弹。内容分阶段显现，移开后平滑收回，反向触发不会被旧动画关闭。
- 左侧四个矢量图标入口：投送、美化、录音、接力。投送和美化支持文件拖入；没有选中素材时可选择文件。
- 卡片横向排列，可滚轮浏览、直接点击图钉固定；选中后显示复制 / 固定 / 移除。中文和英文字体使用系统字体回退，图标不依赖字体字符。
- 新安装默认自动收纳文字、链接、截图、文件引用；顶部绿点可一键暂停。旧版中已经保存的关闭设置会保留，点击“剪贴板已暂停 · 点击开启”即可开启。
- 系统剪贴板通知结合重试，避免被占用时漏收；相同图片不会重复入库。文件引用不会移动或改写源文件。
- 设置可开启“减少动态效果”，也遵循系统的动画开关。

更新时先从系统托盘退出旧版，将新版解压到新目录。已有收纳架和设置保留在同一数据目录；不需要删除它们。

## 已实现的工作流

| Mac 功能 | Windows 实现 |
|---|---|
| 刘海 / 无刘海屏幕 | 设置里选择“刘海”或“小把手”，不按 M1 / Intel 判定；默认小把手 |
| 顶边悬停展开、移开收起 | 连续轮廓变形与弹性回落，收起时不抢焦点；显示器和 DPI 变化后重新定位 |
| 文件、目录、截图、文字、链接 | 拖入或 Ctrl+V；文件保留原路径，文字和图片本地保存 |
| 多选、批次堆叠、类型分组 | Ctrl / Shift 多选、空白区域框选、分组按钮切换批次 / 类型 / 平铺 |
| 拖出 / 重排 | 文件拖到资源管理器或其他应用，文字拖到输入框；岛内拖到另一张卡片前排序 |
| 固定和保留时长 | 固定项优先显示，不受移除、清空或过期影响；6 / 24 / 72 小时 |
| 双击打开、预览、复制 | 图片 / 文字预览，其他文件由默认应用打开；空格预览、Delete 移除卡片 |
| 窗口暂存 | 原生 Win32 最小化并记录窗口；双击或快捷键还原，退出 Ledge 后仍可从任务栏找回 |
| 截图美化 | 8 种渐变背景、圆角、阴影；菜单或拖到美化按钮，结果加入收纳架及剪贴板 |
| 接力文件夹 | 选择本地或 OneDrive 等同步目录；复制不覆盖已有文件，可多选拖出和加入收纳架 |
| AirDrop | Windows 原生共享面板；可用的目标和“附近共享”由系统及已安装应用决定 |
| 系统声音 + 麦克风会议录音 | WASAPI 采集，混为 48 kHz 立体声 WAV，停止后加入收纳架；30 分钟自动停止 |
| 剪贴板捕获 | 新安装默认开启，可在顶栏或设置暂停；支持文字 / 链接 / 截图 / 文件引用，排除常见密码管理器及标记为私密的来源 |
| 快捷键、多屏 | 三个全局快捷键可修改；所有显示器 / 仅主屏可选 |

默认快捷键：`Ctrl+Alt+Space` 展开 / 收起，`Ctrl+Alt+L` 暂存当前其他应用窗口，`Ctrl+Alt+Shift+L` 还原最近窗口。展开后点击岛内即可使用 Ctrl+V / Ctrl+C / Ctrl+A。

数据位于 `%LOCALAPPDATA%\Ledge`，包含 `shelf.json`、`settings.json` 和 `blobs`。录音保存到用户选择的目录。清空 / 移除只移除卡片，不删除源文件；生成的图片也保留在 blobs，避免误删用户素材。损坏的 JSON 索引会保留备份并显示提示。

## 与 Mac 的平台差异

- Windows 无法使用 Apple AirDrop、AppKit、Sparkle 或 Apple 的 iCloud 文件协调接口；使用系统共享、Win32、手动更新和用户自己的同步目录。
- Windows 暂存窗口以系统最小化实现，当前预览使用标题列表，没有 Mac 版的窗口快照缩略图。
- Windows 录音格式为 WAV，Mac 为 AAC M4A；当前最长 30 分钟。音频设备切换、休眠、权限不足、超过立体声的设备会提示失败，并尽量保留已写入文件。
- 浏览器链接由默认浏览器打开，暂不提供 Mac 版的“切回原有标签页”；接力页当前在打开或复制完成后刷新。
- 启动项安装、自动更新、安装器和正式签名尚未配置；不修改或发布 Mac 官网与更新源。

## 开发与构建

需要 .NET 10 SDK，版本由 `global.json` 指定。Windows 下：

```powershell
cd Windows
dotnet restore src/Ledge.Windows/Ledge.Windows.csproj --locked-mode
dotnet run --project tests/Ledge.Core.Checks -c Release
dotnet run --project tests/Ledge.Audio.Checks -c Release
dotnet run --project src/Ledge.Windows
dotnet run --project src/Ledge.Windows -c Release -- --self-test "$PWD/artifacts/desktop-native"
pwsh -File scripts/Build.ps1 -Runtime win-x64
```

Linux 可以运行核心检查并交叉编译 / 发布 Windows 包；本环境另用 Wine 补充运行 WPF，但不能替代原生 Windows 系统接口和硬件验收：

```bash
dotnet run --project tests/Ledge.Core.Checks -c Release
dotnet run --project tests/Ledge.Audio.Checks -c Release
dotnet build src/Ledge.Windows/Ledge.Windows.csproj -c Release
dotnet publish src/Ledge.Windows/Ledge.Windows.csproj -c Release -r win-x64 --self-contained true -o artifacts/Ledge-win-x64
```

`Ledge.Core` 管理索引、固定 / 过期策略和接力复制；`Ledge.Audio` 提供与测试共用的采样、混音、WAV 和录音生命周期；`Ledge.Windows` 管理 WPF、Win32、WASAPI 适配器和原生共享。诊断日志位于数据目录 `diagnostics.log`，1MB 轮转。NAudio 使用 MIT 许可证；开源参考来源见 [THIRD-PARTY.md](THIRD-PARTY.md)。
